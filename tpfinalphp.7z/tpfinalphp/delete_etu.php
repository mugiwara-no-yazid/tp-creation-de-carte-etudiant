<?php

foreach($_REQUEST["id"] as $id)
{   $req=sprintf("SELECT * FROM carteetu WHERE id = '%d'", $id);
    $result=mysqli_query($con,$req);
    $ligne = mysqli_fetch_assoc($result);
    unlink($ligne['Photo']);
    unlink($ligne['Qrcode']);
    $req=sprintf ("DELETE FROM carteetu where id='%s'", $id);
    $result=mysqli_query($con,$req);  
}
header ("Location:listeinscr.php?page=list");

?>