<?php 
include("./inclus/entete.php");
require_once("./inclus/consql.php");

//ouvrir le tableau de liste 
if ($_REQUEST["page"] == "list")
{
    $req = "SELECT * FROM carteetu";
    $result = mysqli_query($con,$req);
    echo ("<h1>Liste Inscrit</h1>");
    echo ("<form action=\"listeinscr.php?page=del\" method=\"post\" id=\"etuliste\"> ");
    echo ("<table>");
    echo(" <thead> <tr> <th>SELECT</th> <th>NOM</th> <th>PRENOM</th> <th>CLASSE</th> <th>CONTACT</th> <th>EDITER</th></tr> </thead>");
    echo ("<tbody>");
    $syle =0;
    while($ligne = mysqli_fetch_assoc($result))
    {
        $id = $ligne["id"];
        $mat = $ligne["Matricule"];
        $nom = $ligne["Nom"];
        $prenom = $ligne["Prenom"];
        $datnai = $ligne["DatnNais"];
        $lieunais = $ligne["LieuNais"];
        $classe = $ligne["Classe"];
        $filiere = $ligne["Fillière"];
        $contact = $ligne["Contact"];
        $photo =$ligne["Photo"];
        $qr = $ligne["Qrcode"];
        if ($syle%2==0)
        { echo ("<tr >");}
        else
        {
            echo ("<tr class =\"changecouleur\">");
        }
       
        echo("<td><input type=\"checkbox\" name='id[]' value='$id'></td> <td><a href=\"formulaire.php?id=$id&Photo=$photo&Qrcode=$qr\"> $nom </a></td> <td>$prenom</td> <td>$classe</td> <td>$contact</td> <td> <img src=\"./imagesite/editer.png\" alt=\"crayon\" class='modal_open' data-mat='$mat'> </td> </tr> ");
        $syle++;
    }
    echo ("</tbody> </table>");	
    echo("<input type=\"submit\" value=\"Effacer\" class=\"envoyer\">");
    echo("</form>");
}
else if ($_REQUEST["page"] == "del")
{
    include("delete_etu.php");
}
else if ($_REQUEST["page"] == "voiretu")
{
    include("voiretu.php");
}

//fenetre modale
echo "<div class=\"modal_container\">";
    echo "<div class=\"gris trigger\"></div>";
    echo "<div class=\"modal_contenu\">";
        echo "<button class=\"close trigger\">X</button>";
        echo "<div class=\"carte\">";
        echo "    <h1>Appercu de la carte</h1>";
        echo "    <p>JE VAIS ADAPTER LE CONTENU POUR Y METTRE LA CARTE ETUDIANT</p>";
        //include("voiretu.php");
        echo "</div>";
    echo "</div>";
echo "</div>";
echo "<script src=\"./inclus/app.js\"></script>" ;
include("./inclus/foot.php");
?>