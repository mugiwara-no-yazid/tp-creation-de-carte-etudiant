<fieldset>
        <legend>
            <h1>Formulaire</h1>
        </legend>
        <img src="love.png" alt="" width="120" height="auto" id ="formimg">
         <form action="nous_contacter.php" method="post" name="Mon formulaire" id ="formilaire_contacte">
            <h2> Nous Contacter</h2>
            <p> <input type="hidden" name="destinataire" value="carteetu618@gmail.com"></p>
            <p><label>Email:</label> <input type="text" name="email" placeholder="Entrez votre email ..." required autofocus></p>
            <p><label>Objet:</label><input type="text" name="subject" placeholder="Objet du message" required ></p>
            <label>Message:</label>
            <textarea name="message" cols="30" rows="10" placeholder="Votre message" required ></textarea> </p>
            <button class="envoyer">Envoyer</button>    
        </form>
</fieldset> 
