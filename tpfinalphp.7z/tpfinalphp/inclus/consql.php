<?php
define("HOST","localhost");
define("USER","root");
define("PSSWRD","");
define("BDD","l1irt");

$con = mysqli_connect(HOST,USER,PSSWRD,BDD) or die('Connexion impossible');
?>