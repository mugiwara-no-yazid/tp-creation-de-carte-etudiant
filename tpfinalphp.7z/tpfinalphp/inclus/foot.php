</main>
<footer>
© 2024 Mon Site Web
</footer>
</body>
</html>