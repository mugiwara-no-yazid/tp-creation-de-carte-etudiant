<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Aceuil</title>
</head>
<body>
    <header>
            <img src="./imagesite/logo_esgis.png" alt="logo_esgis">
            <h1>ESGIS</h1>
            <input type="text" name="recherche" id="recherche" placeholder="Rechercher🔎...">
    </header>
        <nav>
            <a href="./index.php">Acceuil</a>
            <a href="quisn.php">Qui somme-nous</a>
            <a href="formulaire.php">Ajouter Etudiant</a>
            <a href="listeinscr.php?page=list">Afficher Etudiant</a>
            <a href="nous_contacter.php">Nous contacter</a>
        </nav>
        <main>

