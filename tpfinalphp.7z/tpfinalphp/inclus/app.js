var modal = document.querySelector(".modal_container");
var triggers = document.querySelectorAll(".trigger");
var buton = document.querySelectorAll(".modal_open");
var modalContent = document.querySelector (".carte");
triggers.forEach(trigger => trigger.addEventListener("click",function(e)
{
    modal.classList.toggle("visible");   

}));
buton.forEach(btn=>btn.addEventListener("click",function(e)
{
    var mat = this.getAttribute('data-mat');
     fetch(`voiretu.php?mat=${mat}`)
            .then(response => response.text())
            .then(data => {
                modalContent.innerHTML = data;
            })
    modal.classList.toggle("visible");   

}));



