<?php 
  include("inclus/entete.php");
  if ($_SERVER["REQUEST_METHOD"] == "POST")
  {
      $destinataire = $_POST["destinataire"];
      $email=$_POST["email"];
      $subject = $_POST["subject"];
      $header = "From: $email\r\n";
      $header .= "Reply-To: $email\r\n";
      $header .= "X-Mailer: PHP/" . phpversion();

      $message = $_POST["message"];       
// Envoi de l'e-mail
      if(mail($destinataire, $subject, $message,  $header)){
         echo "<p class=\"request_message\">Message envoyé !</p>";
        }
      else{
         echo "<p class=\"request_message\">Erreur d'envoie... !</p>";
          }
  }
  else
  {
    include("./inclus/formulaire_nous_contacter.php");
  } 

  include("./inclus/foot.php");?>

   









    
   

