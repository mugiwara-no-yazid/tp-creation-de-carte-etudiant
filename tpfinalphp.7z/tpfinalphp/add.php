<?php 
require("./inclus/consql.php");
require_once("./lib/phpqrcode/qrlib.php");
require_once("./lib/phpqrcode/qrconfig.php");
//recuperer l'extentionde la photo et son nom
$name = $_FILES['photo']['name'];
$ext = strrchr($name, '.');
$ext_autorise = [".png",".jpeg",".jpg"];
//si l'image est de type png ou jpeg
if (in_array(strtolower($ext), $ext_autorise))
{
    //renomer et deplacer la photo de l'etudiants
    $_FILES['photo']['name']="$_REQUEST[prenom]".time()."$ext";
    $nomphoto =$_FILES['photo']['name'];
    $chemin ="photoetu/"."$nomphoto";
    move_uploaded_file ($_FILES['photo']['tmp_name'],$chemin);

//Generer le qr code
$contenuqr = "Matricule : $_REQUEST[matricule] lien : listeinscr.php?page=voiretu&mat=$_REQUEST[matricule] ";
$nomqr = "Qr".$nomphoto;
$qrchemin = "qrimg/"."$nomqr";


 if(!file_exists($qrchemin))
    {
        QRcode::png($contenuqr,$qrchemin,);
    }
//insertion des donner dans la bdd
if(isset($_REQUEST["modif"]) and $_REQUEST["modif"] == "oui")
{
    unlink($_REQUEST["ancphoto"]);
    unlink($_REQUEST["ancqr"]);
    $req = sprintf ("UPDATE carteetu set Matricule ='%s', Nom ='%s', Prenom ='%s', DatnNais ='%s', LieuNais ='%s', Classe ='%s', Fillière ='%s', Contact ='%d', Photo ='%s', Qrcode = '%s' WHERE id ='%d'",
    $_REQUEST['matricule'],$_REQUEST['nom'],$_REQUEST['prenom'],$_REQUEST['date_de_naissance'],
    $_REQUEST['lieu_de_naissance'],$_REQUEST['cycle'],$_REQUEST['filière'],
    $_REQUEST['phone'],$chemin,$qrchemin,$_REQUEST['idm']);
}
else
{
        $req=sprintf("INSERT into carteetu(id,Matricule,Nom,Prenom,DatnNais,LieuNais,Classe,Fillière,Contact,Photo,Qrcode) value (NULL,'%s','%s','%s','%s','%s','%s','%s','%d','%s','%s')"
        ,$_REQUEST['matricule'],$_REQUEST['nom'],
        $_REQUEST['prenom'],$_REQUEST['date_de_naissance'],
        $_REQUEST['lieu_de_naissance'],$_REQUEST['cycle'],
        $_REQUEST['filière'],$_REQUEST['phone'],$chemin,$qrchemin);
}
$result = mysqli_query($con,$req);

header ("Location:listeinscr.php?page=list");
}
else
{
    header ("Location: formulaire.php?erreur=ext");
}
?>


