<?php
require_once("./inclus/consql.php");
if ( isset($_REQUEST["mat"])) {
    $req =sprintf("SELECT * FROM carteetu WHERE Matricule = '%s' ",$_REQUEST["mat"]);
    $result = mysqli_query($con,$req);
    $ligne = mysqli_fetch_assoc($result);
    echo "<div class=\"carte\">";
    echo "<div class=\"photo\">";
        echo "<img src=\"$ligne[Photo]\" alt=\"Photo de l'étudiant\">";
    echo "</div>";
    echo "<div class=\"informations\">";
        echo "<table>";
           echo " <tr>";
               echo " <th>Nom :</th>";
               echo " <td>$ligne[Nom] </td>";
            echo "</tr>";
            echo "<tr>";
                echo "<th>Prénom :</th>";
                echo "<td>$ligne[Prenom]</td>";
            echo "</tr>";
            echo "<tr>";
                echo "<th>Cycle :</th>";
                echo "<td>$ligne[Classe]</td>";
            echo "</tr>";
            echo "<tr>";
               echo " <th>Date de naissance :</th>";
                echo "<td>$ligne[DatnNais]</td>";
            echo "</tr>";
            echo "<tr>";
                echo "<th>Lieu de naissance :</th>";
                echo "<td>$ligne[LieuNais]</td>";
           echo " </tr>";
           echo " <tr>";
                echo "<th>Filière :</th>";
                echo "<td>$ligne[Fillière]</td>";
            echo "</tr>";
            echo "<tr>";
               echo " <th>Matricule :</th>";
                echo "<td>$ligne[Matricule]</td>";
            echo "</tr>";
            echo "<tr>";
                echo "<th>Contact :</th>";
                echo "<td>$ligne[Contact]</td>";
           echo " </tr>";
        echo "</table>";
    echo "</div>";
    echo "<div class=\"qrcode\">";
        echo "<img src=\"$ligne[Qrcode]\" alt=\"QR Code\">";
    echo "</div>";
echo "</div>";
}

   


?>
