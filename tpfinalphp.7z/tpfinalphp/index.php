<?php include("./inclus/entete.php");?>
        <main>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores rem aut vitae accusamus odit beatae a quas temporibus quos vero, iure dolor dignissimos delectus exercitationem libero quo reprehenderit vel quisquam.
            Quasi at sequi ipsum aperiam commodi provident facere praesentium? Aspernatur, non accusantium numquam dolor sint facere eveniet facilis deserunt impedit voluptate dolore, sequi aut cumque vel atque corporis veniam quasi?
            Quod corrupti reprehenderit blanditiis eaque laboriosam aut inventore sequi ad repellat velit facilis ullam veniam aperiam fuga, quas rem eos perspiciatis cumque quam eum expedita. Recusandae natus esse nemo inventore?
            Vitae eos quisquam voluptates, optio qui in voluptas quam ducimus dolore soluta quia libero earum reiciendis voluptatibus distinctio dolor, recusandae, corporis eum odit a? Ab animi qui similique perferendis consectetur!
            Laborum quaerat suscipit possimus rerum, tempore placeat at sequi reprehenderit nihil eaque ab consequuntur aliquam repellat numquam voluptatibus iusto minus illo quas quo beatae totam id ipsa, doloribus veniam. Nesciunt!
            Maxime, alias delectus dolor impedit asperiores, itaque, dignissimos ipsum quae nemo porro praesentium saepe at. Velit reprehenderit quibusdam aspernatur facilis. Vel laboriosam in modi nulla. Necessitatibus pariatur mollitia earum molestias?
        </main>
<?php include("./inclus/foot.php");?>