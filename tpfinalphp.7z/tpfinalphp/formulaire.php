<?php 
include('./inclus/entete.php');
require_once("./inclus/consql.php");
if (isset($_REQUEST["id"])) {
    $req =sprintf("SELECT * FROM carteetu WHERE id = '%d'", $_REQUEST["id"]);
    $result = mysqli_query($con,$req);
    $ligne = mysqli_fetch_assoc($result);
    }
    if (isset($_REQUEST["erreur"]))
    {
        echo "<p class=\"request_message\">Veuiller envoyer une image .jpg, .png ou .jpeg !</p>";
    } 
?>

<h2 id="form">S'inscrire</h2>
<form method="post" action="<?php if(isset($ligne)){echo "add.php?modif=oui&idm=$_REQUEST[id]&ancphoto=$_REQUEST[Photo]&ancqr=$_REQUEST[Qrcode]";}else{echo "add.php";} ?>" enctype="multipart/form-data" id ="soumission">
        <label for="nom">Nom</label>
        <input type="text" id="nom" name="nom" placeholder="Entrez votre nom en majuscule" autofocus required <?php if(isset($ligne)){echo "value = ", $ligne["Nom"];}?>>
        <label for="prenom">Prénom</label>
        <input type="text" id="prenom" name="prenom" placeholder="Entrez votre prénom"  required <?php if(isset($ligne)){echo "value = ", $ligne["Prenom"];}?>>
        <label for="cycle">Cycle</label>
        <select id="cycle" name="cycle">
            <option value="Licence 1"<?php if(isset($ligne) && $ligne["Classe"]=='Licence 1'){echo "selected";}?>>Licence 1</option>
            <option value="Licence 2"<?php if(isset($ligne) && $ligne["Classe"]=='Licence 2'){echo "selected";}?>>Licence 2</option>
            <option value="Licence 3"<?php if(isset($ligne) && $ligne["Classe"]=='Licence 3'){echo "selected";}?>>Licence 3</option>
            <option value="Master 1" <?php if(isset($ligne) && $ligne["Classe"]=='Master 1'){echo "selected";}?> >Master 1</option>
            <option value="Master 2" <?php if(isset($ligne) && $ligne["Classe"]=='Master 2'){echo "selected";}?> >Master 2</option>
            <option value="Doctorat" <?php if(isset($ligne) && $ligne["Classe"]=='Doctorat'){echo "selected";}?> >Doctorat</option>
         </select>
         <label for="datedenaissance">Date de naissance</label>
         <input type="date" id="datedenaissance" name="date de naissance"  min="1985-01-01" max="2008-12-31" placeholder="Entrez votre date de naissance" required  <?php if(isset($ligne)){echo "value = ", $ligne["DatnNais"];}?>>
         <label for="lieudenaissance">Lieu de naissance</label>
         <input type="text" id="lieudenaissance" name="lieu de naissance" placeholder="Entrez votre lieu de naissance"  required <?php if(isset($ligne)){echo "value = ", $ligne["LieuNais"];}?>>
        <label for="filière">Filière</label>
        <input type="text" id="filière" name="filière" placeholder="Entrez votre filière"  required  <?php if(isset($ligne)){echo "value = ", $ligne["Fillière"];}?>>
        <label for="matricule">Matricule</label>
        <input type="text" id="matricule" name="matricule" placeholder="Entrez votre matricule"  required <?php if(isset($ligne)){echo "value = ", $ligne["Matricule"];}?>>
        <label for="phone">Contact</label>
        <input type="tel" id="phone" name="phone" pattern="[0-9]{2}[0-9]{2}[0-9]{2}[0-9]{2}" placeholder="XX-XX-XX-XX"  required <?php if(isset($ligne)){echo "value = ", $ligne["Contact"];}?>>
        <label for="photo">Entrez votre photo</label>
        <input type="file" name="photo" accept="image/png, image/jpeg" required >
        </select>
        <p>
        <input type="submit" <?php if(isset($ligne)){echo "value='Modifier'";} else{echo "value='Soumettre'";}?> class="envoyer"></p>

</form>
<?php include("./inclus/foot.php");?>